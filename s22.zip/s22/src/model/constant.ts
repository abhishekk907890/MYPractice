 import { User } from './user';
import { Vehicle } from './vehicle';
export const  cacheMemory: Map<string, Object> = new Map();
 //export const  VehicleListConst: Vehicle[] = [];
//export const userDetails:User=new User();


//
//  
//function generateGetterAndSetter(target: Object, key: string) {
//    var getMethodName = 'get' + key.charAt(0).toUpperCase() + key.slice(1);
//    var setMethodName = 'set' + key.charAt(0).toUpperCase() + key.slice(1);
//
//    target[getMethodName] = function() {
//        return this[key];
//    };
//    target[setMethodName] = function(val) {
//        this[key] = val;
//    };
//  
//  
//  
// 
//  
//}
//
//
//

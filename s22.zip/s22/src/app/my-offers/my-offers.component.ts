import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-offers',
  templateUrl: './my-offers.component.html',
  styleUrls: ['./my-offers.component.css']
})
export class MyOffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

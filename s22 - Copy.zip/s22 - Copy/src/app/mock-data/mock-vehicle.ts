
import { Vehicle } from '../../model/vehicle';
export const vehicle:Vehicle[] =[];
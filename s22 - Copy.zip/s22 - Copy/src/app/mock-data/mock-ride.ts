import { OfferRide } from '../../model/offerride';
import { Ride } from '../../model/ride';

//export const rideq:(Ride) ={"isTakeRide":false,"startRide":{},"endRide":{},};
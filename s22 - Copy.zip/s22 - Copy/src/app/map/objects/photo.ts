export interface Photo {
    height: number;
    html_attributions: string[];
    width: number;
}
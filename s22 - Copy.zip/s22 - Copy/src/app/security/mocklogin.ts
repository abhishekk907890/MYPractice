import { appUsersAuth } from './app-users-auth';

  
  export const LOGIN_MOCKS:appUsersAuth[]=[
  {
    userName:"abhishek",
  isAuthinticated:true,
  bearerToken:"ksjfgshfghsghjffdfhshdgfs",
  canViewVehicle:true,
 canViewRide:true,
 canViewWallet:true,
canViewSettings:true
    },
    {
    userName:"df",
      bearerToken:"daffafaf",
      isAuthinticated:true,
       canViewVehicle:true,
 canViewRide:true,
 canViewWallet:true,
canViewSettings:true
    }
  
  ];
  
  
